public class DataTypes
{  
    public static void main(String args[])  
    {  
        boolean flag = true;  
        char ch = 's';  
        int num = 1234;  
        byte size = 2;  
        short srt = 78;  
        double value = 2.4544;  
        float temp = 3.8f;  
        long val = 1888889;  
        System.out.println("boolean: " + flag);  
        System.out.println("char: " + ch);  
        System.out.println("integer: " + num);  
        System.out.println("byte: " + size);  
        System.out.println("short: " + srt);  
        System.out.println("float: " + value);  
        System.out.println("double: " + temp);  
        System.out.println("long: " + val);  
    }  
}  
